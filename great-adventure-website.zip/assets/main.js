// Mobile hamburger menu toggle
function toggleMenu(){
  document.getElementById('hamburger').classList.toggle('open');
  document.getElementById('mobileMenu').classList.toggle('open');
}
document.addEventListener('click', function(e){
  const menu = document.getElementById('mobileMenu');
  const burger = document.getElementById('hamburger');
  if(!menu || !burger) return;
  if(menu.classList.contains('open') && !menu.contains(e.target) && !burger.contains(e.target)){
    menu.classList.remove('open');
    burger.classList.remove('open');
  }
});

// Offer banner — reads from Supabase, set up per SETUP-GUIDE.md
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";

async function loadOfferBanner(){
  if(SUPABASE_URL.indexOf("PASTE_") === 0) return;
  try{
    const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    const { data, error } = await sb.from("announcements").select("*").eq("id", 1).single();
    if(error || !data || !data.active) return;
    document.getElementById("offer-banner-text").textContent = data.title + (data.message ? " — " + data.message : "");
    document.getElementById("offer-banner").style.display = "block";
  }catch(e){ /* fail silently, site works fine without the banner */ }
}
loadOfferBanner();
